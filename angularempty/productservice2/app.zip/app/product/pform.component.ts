import {Component, Output,EventEmitter, Input,SimpleChanges } from "@angular/core";
import {ProductService} from "../product.service";
import { Product } from '../product';

@Component({
    selector:'pform',
    templateUrl:'pform.component.html',
    styleUrls:['pform.component.css']
})
export class PformComponent{

    pid:number;
    pname:string;
    qty:number;
    @Input("pdata") prod:Product;
    @Input("operation") uflag:boolean;
    
    @Output() insprod=new EventEmitter();
    @Output() disp=new EventEmitter();
    constructor(private pservice:ProductService){}

    ngOnChanges(changes:SimpleChanges){
         if(changes["prod"].currentValue!=changes["prod"].previousValue){
             this.pid=this.prod.pid;
             this.pname=this.prod.pname;
             this.qty=this.prod.qty;

         }
    }

    addProduct(){
        let p=new Product(this.pid,this.pname,this.qty);
        this.pservice.addProduct(p).subscribe(p=>console.log(p));
        this.disp.emit(false);
        this.insprod.emit(true);
        
        
    }
    updateProduct(){
        let p=new Product(this.pid,this.pname,this.qty);
        this.pservice.updateProduct(p).subscribe(p=>console.log(p));
        this.disp.emit(false);
        this.insprod.emit(true);
    }


}