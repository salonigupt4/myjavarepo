import {Component, OnInit,SimpleChanges} from "@angular/core";
import {Product} from "../product";
import {ProductService} from "../product.service";

@Component({
    selector:"prodtab",
    templateUrl:"prodtab.component.html",
    styleUrls:["prodtab.component.css"]
})
export class ProdtabComponent implements OnInit{
    prodarr:Product[];
    msg:boolean;
    formflag:boolean=false;
    opflag:boolean;
    prod:Product
    constructor(private pservice:ProductService){}

    ngOnInit(){
       this.pservice.getAllProduct().
        subscribe(proddata=>{this.prodarr=proddata});
    }

    ngOnChanges(changes:SimpleChanges){
          if(changes["msg"].currentValue!=changes["msg"].previousValue){
              this.pservice.getAllProduct().
               subscribe(proddata=>{this.prodarr=proddata});
          }
    }
    
    addData(){
          this.formflag=true;
          this.opflag=false; 

    }
    deleteProduct(p:Product){
        console.log("in delete product component");
        this.pservice.deleteProduct(p).subscribe(p=>console.log(p));
        this.pservice.getAllProduct().
               subscribe(proddata=>{this.prodarr=proddata});

    }
    editProduct(p:Product){
        this.opflag=true; 
        this.formflag=true;
        this.prod=new Product(p.pid,p.pname,p.qty);
          
    }




}