export class Product{
    pid:number;
	 pname:string;
     qty:number;
     constructor(pid:number,pname:string,qty:number){
         this.pid=pid;
         this.pname=pname;
         this.qty=qty;
     }
}