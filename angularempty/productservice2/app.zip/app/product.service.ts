import { Injectable } from '@angular/core';
import {HttpClient,HttpHeaders} from '@angular/common/http';
//import {RequestOptions} from '@angular/'
import {Product} from "./product";
import { Observable } from 'rxjs';
import {map,retry} from 'rxjs/operators'

@Injectable()
export class ProductService{

    private prodarr:Product[]
    constructor(private httpClient:HttpClient){}
    //prodarr:Product[];
    private baseUrl="http://localhost:9090/MySpringRestDemo/products";

    getAllProduct():Observable<Product[]>{
       return this.httpClient.get<Product[]>(this.baseUrl);//.pipe(retry(3);catch());

    }
    addProduct(p:Product):Observable<Product>{
        let pheaders = new HttpHeaders({
            'Content-Type': 'application/json'
            
         });
         let options = {
            headers: pheaders
         }
        
        return this.httpClient.post<Product>(this.baseUrl+"/product",p,options);
        
    };
    deleteProduct(p:Product):Observable<Product>{
        console.log("in delete from service");
        console.log(this.baseUrl+"/product/"+p.pid)
        return this.httpClient.delete<Product>(this.baseUrl+"/product/"+p.pid)
    }
    updateProduct(p:Product):Observable<Product>{
        let pheaders=new HttpHeaders({"Content-Type":"application/json"})
        let options = {
            headers: pheaders
         }
        return this.httpClient.put<Product>(this.baseUrl+"/product",p,options)
    }

    
}