import {Injectable} from "@angular/core";

@Injectable()
export class ProductService{
    private prodarr=[{id:111,name:"lays",desc:"very crispy",price:40.00},
    {id:111,name:"maggi",desc:"very snacky",price:50.00},
    {id:111,name:"nachos",desc:"yummmmy",price:60.00},
    {id:111,name:"dairy milk",desc:"very tastty",price:50.00}]

    getAllProducts(){
        return this.prodarr;
    }

}