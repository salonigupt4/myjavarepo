package com.demo.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.demo.bean.Product;
import com.demo.service.ProductService;

@Controller
@RequestMapping("/product")
public class ProductController {
	@Autowired
	ProductService productService;
	
	@RequestMapping("/addproduct")
	public String displayForm() {
		return "addproductform";
		
	}
	
	@RequestMapping(value="/save",method=RequestMethod.POST)
	public ModelAndView saveProduct(@RequestParam("pid") int id,@RequestParam String pname,@RequestParam int qty) {
		Product p=new Product(id,pname,qty);
		productService.addProduct(p);
		return new ModelAndView("redirect:viewproducts");
		
	}
	
	@RequestMapping("/viewproducts")
	public ModelAndView getAllProducts() {
		List<Product> plist=productService.getAllProduct();
		return new ModelAndView("displayProduct","plist",plist);
	}
	
	@RequestMapping("/edit/{id}")
	public ModelAndView editProduct(@PathVariable("id") int pid) {
		Product p= productService.getProductById(pid);
		return new ModelAndView("updateProduct","product",p);
		
	}
	
	@RequestMapping("/update")
	public ModelAndView updateProduct(@RequestParam("pid") int id,@RequestParam String pname,@RequestParam int qty) {
		Product p=new Product(id,pname,qty);
		productService.updateProduct(p);
		return new ModelAndView("redirect:viewproducts");
		
	}
	
	@RequestMapping("/delete/{id}")
	public ModelAndView deleteProduct(@PathVariable int id) {
		productService.deleteProduct(id);
		return new ModelAndView("redirect:viewproducts");
		
		
	}
	
	
	

}
