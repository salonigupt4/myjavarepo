package com.demo.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.demo.bean.Product;

@Repository//<bean id="pdao"  class="com.demo.doa.ProductDao">
public class ProductDaoImpl implements ProductDao{
	@Autowired
    private JdbcTemplate jdbcTemplate;
	public void saveProduct(Product p) {
		jdbcTemplate.update("insert into product1(pid,pname,qty) values(?,?,?)", new Object[]{p.getPid(),p.getPname(),p.getQty()});
		
	}
	@Override
	public List<Product> findAll() {
	/*	List<Product> plist=jdbcTemplate.query("select * from product1", new RowMapper<Product>() {

			@Override
			public Product mapRow(ResultSet rs, int rowNum) throws SQLException {
				Product p=new Product();
				p.setPid(rs.getInt(1));
				p.setPname(rs.getString(2));
				p.setQty(rs.getInt(2));
				return p;
			}

			
			
		});*/
		List<Product> plist=jdbcTemplate.query("select * from product1", (ResultSet rs, int rowNum) -> {
				Product p=new Product();
				p.setPid(rs.getInt(1));
				p.setPname(rs.getString(2));
				p.setQty(rs.getInt(3));
				return p;
			});
		
		return plist;
	}
	@Override
	public int deleteProduct(int id) {
		return jdbcTemplate.update("delete from product1 where pid=?",new Object[] {id});
		}
	@Override
	public int updateProduct(int id, int qty) {
		return jdbcTemplate.update("update product1 set qty=? where pid=?",new Object[] {qty,id});
	}
	@Override
	public Product findById(int id) {
		String sql="select * from product1 where pid=?";
		RowMapper<Product> r=(ResultSet rs,int numr)->{
			Product p=new Product();
			p.setPid(rs.getInt(1));
			p.setPname(rs.getString(2));
			p.setQty(rs.getInt(3));
			return p;
		};
		//new BeanPropertyRowMapper<>()
		return  jdbcTemplate.queryForObject(sql, new Object[]{id}, r);
		/* List<Product>plist=jdbcTemplate.query("select * from product1 where pid=?", new Object[]{id},(ResultSet rs,int numr)->{
			Product p=new Product();
			p.setPid(rs.getInt(1));
			p.setPname(rs.getString(2));
			p.setQty(rs.getInt(3));
			return p;
		});
		 return plist.get(0);*/
	}

}
