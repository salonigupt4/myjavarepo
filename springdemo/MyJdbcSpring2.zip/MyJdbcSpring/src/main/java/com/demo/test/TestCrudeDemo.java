package com.demo.test;

import java.util.List;
import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.demo.bean.Product;
import com.demo.service.ProductService;

public class TestCrudeDemo {

	public static void main(String[] args) {
		ApplicationContext context=new ClassPathXmlApplicationContext("jdbcconfig.xml");
		Scanner sc=new Scanner(System.in);
		int choice=0;
		ProductService productService=(ProductService) context.getBean("productServiceImpl");
		do {
			System.out.println("1. Add product\n2.Display All\3.delete product");
			System.out.println("4.update product\n5.display by id\n6.exit");
			choice=sc.nextInt();
			switch(choice) {
			case 1:
				productService.addProduct();
				
				break;
			case 2:
				List<Product> plist=productService.getAllProduct();
				plist.forEach(System.out::println);
				break;
			case 3:
				System.out.println("enetr productid");
				int id=sc.nextInt();
				int n=productService.deleteProduct(id);
				if(n>0) {
					System.out.println("Product deleted");
				}
				else {
					System.out.println("product not found");
				}
				break;
			case 4:
				System.out.println("enetr productid");
				id=sc.nextInt();
				System.out.println("enetr qty");
				int qty=sc.nextInt();
				 n=productService.updateProduct(id,qty);
				 if(n>0) {
						System.out.println("Product updated");
					}
					else {
						System.out.println("product not updated");
					}
				break;
			case 5:
				System.out.println("enetr productid");
				id=sc.nextInt();
				Product p=productService.getProductById(id);
				if(p!=null) {
					System.out.println(p);
				}
				else {
					System.out.println("product not found"+id);
				}
				break;
			case 6:
				System.exit(0);
				break;
			}
			
			}while(choice!=6);
	}

}
