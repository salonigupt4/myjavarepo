package com.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.demo.bean.Product;
import com.demo.service.ProductService;

@CrossOrigin
@RestController
public class ProductRestController {
	@Autowired
	ProductService productService;
	
	@RequestMapping(value="/products",produces="application/json")//MIME type
	public List<Product> getAllProduct(){
		return productService.getAllProduct();
		
		
	}
	
	
	
	@RequestMapping(value="/products/product",method=RequestMethod.PUT,headers = "Accept=application/json",consumes="application/json")
	public Product updateProduct(@RequestBody Product p) {
		productService.updateProduct(p);
		return p;
	}
	
	@RequestMapping(value="/products/product/{id}",method=RequestMethod.DELETE)
	public Product deleteProduct(@PathVariable("id") int id) {
		Product p=productService.getProductById(id);
		productService.deleteProduct(id);
		return p;
	}
	
	@RequestMapping(value="/products/product",method=RequestMethod.POST,headers = "Accept=application/json",consumes="application/json")
	public Product addProduct(@RequestBody Product p) {
		 productService.addProduct(p);
		 return p;
	}
	
	
	
	

}
