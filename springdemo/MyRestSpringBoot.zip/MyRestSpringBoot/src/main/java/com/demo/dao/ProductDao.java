package com.demo.dao;

import java.util.List;

import com.demo.bean.Product;

public interface ProductDao {

	void saveProduct(Product p);

	List<Product> findAll();

	int deleteProduct(int id);

	int updateProduct(int id, int qty);

	Product findById(int id);

}
