package com.demo.bean;

import java.util.List;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.BeanFactoryAware;
import org.springframework.beans.factory.BeanNameAware;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;

public class User implements ApplicationContextAware,BeanNameAware,BeanFactoryAware,InitializingBean,DisposableBean{
	private int uid;
	private String name;
	private List<Address> addr1;
	
	public User() {
		super();
		//System.out.println("in user default constructor");
	}
	
	public User(int uid, String name, List<Address> addr1) {
		super();
		this.uid = uid;
		this.name = name;
		this.addr1 = addr1;
	}

	public List<Address> getAddr1() {
		return addr1;
	}

	public void setAddr1(List<Address> addr1) {
		this.addr1 = addr1;
	}

	public int getUid() {
		return uid;
	}
	public void setUid(int uid) {
		//System.out.println("in user setuid");
		this.uid = uid;
	}
	public String getName() {
		System.out.println("in getname method");
		return name;
	}
	public void setName(String name) {
		//System.out.println("in user setName");
		this.name = name;
	}
	
    public void method1(int x,String a) {
    	
    	System.out.println(x+"-----"+a);
    	
    }


	@Override
	public String toString() {
		return "User [uid=" + uid + ", name=" + name + ", addr1=" + addr1 + "]";
	}

	public void setBeanName(String name) {
		//System.out.println("in setBeanName()"+name);
		
	}

	public void setBeanFactory(BeanFactory beanFactory) throws BeansException {
		//System.out.println("in setBeanFactory()"+beanFactory);
		
	}

	public void afterPropertiesSet() throws Exception {
		//System.out.println("in afterpropertieset()");
		
	}
	
	public void myinit() {
		//System.out.println("in myinit()");
	}

	public void destroy() throws Exception {
		//System.out.println("in destroy of disposable");
		
	}
	
	public void mydestroy() {
		System.out.println("in custom destroy of disposable");
		
	}

	public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
		System.out.println("in applicationcontext aware");
		
	}

}
