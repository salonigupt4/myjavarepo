package com.demo.test;

import org.springframework.core.io.ClassPathResource;

import com.demo.bean.HelloInterface;
import com.demo.bean.HelloWorld;
import com.demo.bean.User;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestHello {
	public static void main(String[] args) {
		//BeanFactory bf=new XmlBeanFactory(new ClassPathResource("helloconfig.xml"));
		//System.out.println("after beanFactory");
		ApplicationContext context=new ClassPathXmlApplicationContext("helloconfig.xml");
		System.out.println("after ApplicationContext");
		//HelloInterface hello=(HelloWorld) context.getBean("hello");
		//System.out.println(hello.sayHello());
		User u1=(User) context.getBean("u1");
		System.out.println("name: "+u1.getName());
		u1.method1(10,"Rajan");
		//System.out.println(u1);
		//((AbstractApplicationContext) context).close();
		//User user=(User) context.getBean("u2");
		//System.out.println("name: "+user.getName());
	}

}
