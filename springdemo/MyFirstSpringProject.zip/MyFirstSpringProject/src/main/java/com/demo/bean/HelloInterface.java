package com.demo.bean;

public interface HelloInterface {
	public String sayHello();
}
