package com.demo.aop;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class MyApsect {
	@Before("execution(* com.demo.*.U*.*(..))")
	public void beforeAdvice() {
		System.out.println("In before advice");
	}
	
	
	@After("execution(* com.demo.bean.*.*(int,String))")
	public void afterAdvice() {
		System.out.println("In after advice");
	}
	
	@Around("execution(* com.demo.bean.*.*(..))")
	public Object aroundAdvice(ProceedingJoinPoint pjoin) throws Throwable {
		System.out.println("In around advice before proceed");
		Object data=pjoin.proceed();
		System.out.println("In around advice after proceed");
		return data;
	}
	
	
}
