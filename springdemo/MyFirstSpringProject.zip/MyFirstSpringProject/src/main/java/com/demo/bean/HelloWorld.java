package com.demo.bean;

public class HelloWorld implements HelloInterface{
	public HelloWorld() {
		System.out.println("In hello constructor");
	}
	public String sayHello() {
		return "Hello world, welcome to spring programming";
	}

}
