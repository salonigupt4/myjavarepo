package com.demo.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.demo.bean.Product;

@Repository//<bean id="pdao"  class="com.demo.doa.ProductDao">
public class ProductDaoImpl implements ProductDao{
	@Autowired
    JdbcTemplate jdbcTemplate;
	public void saveProduct(Product p) {
		jdbcTemplate.update("insert into product1 values(?,?,?)", new Object[]{p.getPid(),p.getPname(),p.getQty()});
		
	}
	@Override
	public List<Product> findAll() {
	/*	List<Product> plist=jdbcTemplate.query("select * from product1", new RowMapper<Product>() {

			@Override
			public Product mapRow(ResultSet rs, int rowNum) throws SQLException {
				Product p=new Product();
				p.setPid(rs.getInt(1));
				p.setPname(rs.getString(2));
				p.setQty(rs.getInt(2));
				return p;
			}

			
			
		});*/
		List<Product> plist=jdbcTemplate.query("select * from product1", (ResultSet rs, int rowNum) -> {
				Product p=new Product();
				p.setPid(rs.getInt(1));
				p.setPname(rs.getString(2));
				p.setQty(rs.getInt(2));
				return p;
			});
		
		return plist;
	}

}
