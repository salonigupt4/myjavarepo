package com.demo.service;

import java.util.List;
import java.util.Scanner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.demo.bean.Product;
import com.demo.dao.ProductDao;

@Service
public class ProductServiceImpl implements ProductService {
	@Autowired
	//@Qualifier("pdao1")
	private ProductDao productDao;

	public void addProduct() {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter id");
		int pid=sc.nextInt();
		System.out.println("enter name");
		String name=sc.next();
		System.out.println("enter qty");
		int qty=sc.nextInt();
		Product p=new Product(pid,name,qty);
		productDao.saveProduct(p);
		
		
	}

	@Override
	public List<Product> getAllProduct() {
		return productDao.findAll();
	}
	

}
