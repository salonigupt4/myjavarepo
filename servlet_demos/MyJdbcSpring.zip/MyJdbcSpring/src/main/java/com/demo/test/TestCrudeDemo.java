package com.demo.test;

import java.util.List;
import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.demo.bean.Product;
import com.demo.service.ProductService;

public class TestCrudeDemo {

	public static void main(String[] args) {
		ApplicationContext context=new ClassPathXmlApplicationContext("jdbcconfig.xml");
		Scanner sc=new Scanner(System.in);
		int choice=0;
		ProductService productService=(ProductService) context.getBean("productServiceImpl");
		do {
			System.out.println("1. Add product\n2.Display All\3.delete product");
			System.out.println("4.update product\n5.display by id\n6.exit");
			choice=sc.nextInt();
			switch(choice) {
			case 1:
				productService.addProduct();
				break;
			case 2:
				List<Product> plist=productService.getAllProduct();
				plist.forEach(System.out::println);
				break;
			case 3:
				break;
			case 4:
				break;
			case 5:
				break;
			case 6:
				System.exit(0);
				break;
			}
			
			}while(choice!=6);
	}

}
