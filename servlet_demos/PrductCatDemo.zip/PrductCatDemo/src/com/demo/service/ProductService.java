package com.demo.service;

import java.util.List;

import com.demo.bean.Category;

public interface ProductService {

	List<Category> findAllcategory();

}
