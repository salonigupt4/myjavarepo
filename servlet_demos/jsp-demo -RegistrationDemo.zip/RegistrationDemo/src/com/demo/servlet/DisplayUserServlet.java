package com.demo.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.demo.bean.UserDetails;

public class DisplayUserServlet extends HttpServlet {
	static SimpleDateFormat sdf;

	
	public void init() {
		sdf=new SimpleDateFormat("dd/MM/yyyy");
		
	}
	
	
   protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		response.setContentType("text/html");
		//retirive object from rquest object
		UserDetails u=(UserDetails)request.getAttribute("details");
        out.println("Username : "+u.getName());
        out.println("Hobbies : "+u.getHobbies());
        String dt=sdf.format(u.getDoj());
        out.println("Joining date"+dt);
        out.println("Mobile :"+u.getMob());
   };
}