package com.demo.service;

public interface LoginService {

	boolean validateUser(String uname, String pass);

}
