package com.demo.bean;

import java.util.Date;

public class UserDetails {
	private String name,degree,gender,mob,city,hobbies;
	private int age;
	private Date doj;
	public UserDetails() {
		super();
	}
	public UserDetails(String name, String degree, String gender, String mob, String city, String hobbies, int age,
			Date doj) {
		super();
		this.name = name;
		this.degree = degree;
		this.gender = gender;
		this.mob = mob;
		this.city = city;
		this.hobbies = hobbies;
		this.age = age;
		this.doj = doj;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDegree() {
		return degree;
	}
	public void setDegree(String degree) {
		this.degree = degree;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getMob() {
		return mob;
	}
	public void setMob(String mob) {
		this.mob = mob;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getHobbies() {
		return hobbies;
	}
	public void setHobbies(String hobbies) {
		this.hobbies = hobbies;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public Date getDoj() {
		return doj;
	}
	public void setDoj(Date doj) {
		this.doj = doj;
	}
	
	

}
