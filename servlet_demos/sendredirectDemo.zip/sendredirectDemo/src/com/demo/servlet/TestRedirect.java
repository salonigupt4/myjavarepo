package com.demo.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class TestRedirect
 */
@WebServlet("/TestRedirect")
public class TestRedirect extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//response.sendRedirect("http://localhost:9090/PrductCatDemo/");
    	PrintWriter out=response.getWriter();
    	response.setHeader("refresh", "10;Url=http://google.com");
    	out.println(new Date());
    	
		
	}

}
