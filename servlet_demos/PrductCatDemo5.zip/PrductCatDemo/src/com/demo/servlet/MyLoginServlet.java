package com.demo.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.demo.bean.User;
import com.demo.service.LoginService;
import com.demo.service.LoginServiceImpl;


public class MyLoginServlet extends HttpServlet {
	private String msg;
	private int percent;
	
	
	public void init(ServletConfig config) throws ServletException {
		super.init(config);
		System.out.println("in init method");
		 
		 
		
	}
	/*public void init() {
		ServletConfig config=getServletConfig();
		msg=config.getInitParameter("msg");
		percent=Integer.parseInt(config.getInitParameter("percent"));
	}*/
	
	public void destroy() {
		System.out.println("in destroy");
	}
	public void doPost(HttpServletRequest request,HttpServletResponse response) throws IOException, ServletException{
		
		PrintWriter out=response.getWriter();
		response.setContentType("text/html");
		String uname=request.getParameter("uname");
		String pass=request.getParameter("pass");
		LoginService loginService=new LoginServiceImpl();
		User user=loginService.validateUser(uname,pass);
		Cookie[] cookielist=request.getCookies();
		boolean flag=false;
		for(Cookie c:cookielist) {
			System.out.println(c.getName()+"----"+c.getValue());
			if(c.getName().equals("count")) {
				Integer count=Integer.parseInt(c.getValue())+1;
				c.setValue(count.toString());
				c.setMaxAge(7200);
				response.addCookie(c);
				flag=true;
			}
		}
		if(!flag) {
		    Cookie c1=new Cookie("count","1");
		    c1.setMaxAge(7200);
		    response.addCookie(c1);
		}
		if(user!=null){
			HttpSession session=request.getSession();
		    if(session.isNew()) {
		    	session.setAttribute("uname", uname);
		    	session.setAttribute("role",user.getRole());
		    }			
			RequestDispatcher rd=request.getRequestDispatcher("category");
			rd.forward(request, response);
		}
		else {
			out.println("you are not authrized user");
			RequestDispatcher rd=request.getRequestDispatcher("index.html");
			rd.include(request, response);
			
		}
		
		
		
	}

}
