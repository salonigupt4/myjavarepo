package com.demo.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.demo.bean.Product;
import com.demo.service.ProductService;
import com.demo.service.ProductServiceImpl;

/**
 * Servlet implementation class ProductDisplayServlet
 */
//@WebServlet("/viewproduct")
public class ProductDisplayServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		HttpSession session=request.getSession();
		PrintWriter out=response.getWriter();
		Integer cat=(Integer)session.getAttribute("cat");
		if(cat==null) {
	        session.setAttribute("cat",Integer.parseInt(request.getParameter("cat")));
		}
		String role=(String) session.getAttribute("role");
		//check for valid user
		if(role.equals("admin")) {
			
		    cat=(Integer) session.getAttribute("cat"); 
			//int cat=Integer.parseInt(request.getParameter("cat"));
			ProductService productService=new ProductServiceImpl();
			List<Product> plist=productService.getByCategory(cat);
			request.setAttribute("plist",plist);
			RequestDispatcher rd=request.getRequestDispatcher("displayproduct.jsp");
			rd.forward(request, response);
			
		}
		else {
			out.println("you are not autherized user");
			RequestDispatcher rd=request.getRequestDispatcher("index.html");
			session.invalidate();
			rd.include(request, response);
			//out.println("testing");
			
			
		}
		
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request,response);
	}
}
