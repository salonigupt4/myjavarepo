package com.demo.dao;

import java.util.List;

import com.demo.bean.Category;
import com.demo.bean.Product;

public interface ProductDao {

	List<Category> getAllCategory();

	List<Product> findByCategory(int cat);

	int insertProduct(Product p);

	Product getProductById(int pid);

	int updateProduct(Product p);

}
