package com.demo.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.demo.bean.Product;
import com.demo.service.ProductService;
import com.demo.service.ProductServiceImpl;

/**
 * Servlet implementation class AddProductServlet
 */
//@WebServlet("/addproduct")
public class AddProductServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		HttpSession session=request.getSession();
		PrintWriter out=response.getWriter();
		String role=(String) session.getAttribute("role");
		if(role!=null && role.equals("admin")) {
			
			int pid=Integer.parseInt(request.getParameter("pid"));
			String pname=request.getParameter("pname");
			int qty=Integer.parseInt(request.getParameter("pqty"));
			double price=Double.parseDouble(request.getParameter("pprice"));
			int cid=Integer.parseInt(request.getParameter("pcat"));
			Product p=new Product(pid,pname,qty,price,cid);
			ProductService pService=new ProductServiceImpl();
			int n=pService.addproduct(p);
			System.out.println("product added");
			//RequestDispatcher rd=request.getRequestDispatcher("viewproduct?cat="+cid);
			RequestDispatcher rd=request.getRequestDispatcher("viewproduct");
			rd.forward(request, response);
		}
		else {
			out.println("you are not autherized user");
			RequestDispatcher rd=request.getRequestDispatcher("index.html");
			session.invalidate();
			rd.include(request, response);
			//out.println("testing");
			
			
		}
		
	}

}
