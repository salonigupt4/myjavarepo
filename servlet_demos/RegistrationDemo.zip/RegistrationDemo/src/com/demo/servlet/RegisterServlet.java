package com.demo.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.demo.bean.UserDetails;

/**
 * Servlet implementation class RegisterServlet
 */
//@WebServlet("/register")
public class RegisterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	static SimpleDateFormat sdf;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	public void init() {
		sdf=new SimpleDateFormat("dd/MM/yyyy");
		
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		response.setContentType("text/html");
		String nm=request.getParameter("nm");
		int age=Integer.parseInt(request.getParameter("age"));		
		String mob=request.getParameter("mob");
		String jdt=request.getParameter("jdt");
		String city=request.getParameter("city");
		String gender=request.getParameter("gender");
		String degree=request.getParameter("degree");
		String[] hobbies=request.getParameterValues("hobbies");
		//create UserDetails object and pass it for display
		UserDetails userDetails=new UserDetails();
		userDetails.setName(nm);
		userDetails.setAge(age);
		userDetails.setMob(mob);
		userDetails.setCity(city);
		userDetails.setGender(gender);
		userDetails.setDegree(degree);
		String hb="".join(",", hobbies);
		userDetails.setHobbies(hb);
		Date dt;
		try {
			dt = sdf.parse(jdt);
			userDetails.setDoj(dt);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		request.setAttribute("details", userDetails);
		RequestDispatcher rd=request.getRequestDispatcher("display.jsp");
		rd.forward(request, response);
		
		
	}

}
