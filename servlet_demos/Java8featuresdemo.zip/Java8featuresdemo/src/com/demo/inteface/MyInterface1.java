package com.demo.inteface;

public interface MyInterface1<T,Integer> {
	T getdata(T t,Integer i);

}
