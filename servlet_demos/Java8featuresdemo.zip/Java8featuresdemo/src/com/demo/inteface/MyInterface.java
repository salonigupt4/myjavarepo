package com.demo.inteface;

@FunctionalInterface
public interface MyInterface<T,R> {
	R getdata(T t,R r);
	
}
