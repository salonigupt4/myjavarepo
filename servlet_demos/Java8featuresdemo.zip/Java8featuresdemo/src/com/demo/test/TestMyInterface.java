package com.demo.test;

import com.demo.inteface.MyInterface;
import com.demo.inteface.MyInterface1;

public class TestMyInterface {

	public static void main(String[] args) {
		MyInterface<String,Integer> ob=(x,y)->{
			return x.length()+y;
		};
        int len=ob.getdata("Hello", 5);
        System.out.println("length: "+len);
        MyInterface<Integer,Integer> ob1=(x,y)->{
			return x+y;
		};
		System.out.println("Anaswer: "+ob1.getdata(12, 12));
		MyInterface<Integer[],Integer> ob2=(x,y)->{
		    return x[y];  
		
	    };
	    Integer[] a= {12,13,14,12,10};
	    System.out.println(ob2.getdata(a,3));
	    MyInterface1<String,Integer> ob3=(x,y)->{
		    String[] test= {"Hello","Welcome","interesting"};
		    return test[y];
		
	    };
	  
	    System.out.println(ob3.getdata("hhh",3));
		
	}
	
	
	
	

}
