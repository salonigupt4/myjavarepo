package com.demo.test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collector;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;

import com.demo.bean.Product;

public class TestStreamFunctions {
	List<Product> plist=new ArrayList<>();
	
	List<Product> getByCondition(Predicate<Product> ob){
		return plist.stream().filter(ob).collect(Collectors.toList());
		
	}
	
	
	
	public static void main(String[] args) {
		List<Product> plist=new ArrayList<>();
		plist.add(new Product(11,"chair",34,2000.00,1));
		plist.add(new Product(11,"table",50,4000.00,1));
		plist.add(new Product(11,"shoe rack",20,4000.00,1));
		plist.add(new Product(11,"Shelf",35,1500.00,1));
		plist.add(new Product(11,"cubboard",35,5500.00,1));
		/*List<Product> plist1=new ArrayList<>();
		for(Product p:plist) {
			if(p.getQty()>30 && p.getPrice()>2000) {
				plist.add(p);
			}
		}*/
		Predicate<Product> ob=p->{
			return p.getQty()>30 && p.getPrice()>2000;
		};
		List<Product> plist2=plist.stream().filter(ob).collect(Collectors.toList());
		plist.stream().filter(ob).forEach(System.out::println);
		
		Integer[] arrint= {5,6,2,3,8};
		//Function<Integer,Integer> fob=x->x*x;
		Arrays.asList(arrint).stream().map(x->x*x).forEach(System.out::println);
		System.out.println(Arrays.asList(arrint).stream().max(Integer::compare));
	    IntStream sint=IntStream.rangeClosed(12,20);
	    sint.forEach(System.out::println);
	    Stream<Integer> s=Stream.iterate(50, n->n+10).limit(10);
	    Stream<Integer> s1= Stream.generate(()->{
	    	return (int) Math.random()*2+1;
	    });
	    s.skip(2).forEach(System.out::println);
		
	}

}
