package com.demo.test;

import java.util.function.Predicate;

import com.demo.bean.Product;

public class TestFunctionalInterface {
	public static void main(String[] args) {
		Product p=new Product(12,"Chair",34,5000.00,2);
		Predicate<String> ob=s->{
			if(s.length()>5)
				return true;
			else 
				return false;
		}; 
		
		if(ob.test("HelloData")) {
			System.out.println("right value");
		}
		else
		{
			System.out.println("Wrong value");
		}
		Predicate<Product> pob=p1->{
			if(p1.getQty()>30 && p1.getPrice()>2000)
			{
				return true;
			}
			else {
				return false;
			}
		};
		
		if(pob.test(p)) {
			System.out.println(p);
		}
		else {
			System.out.println("less quantity");
		}
		
	}

}
