package com.demo.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.demo.bean.Category;
import com.demo.bean.Product;

public class ProductDaoImpl implements ProductDao{
	static Connection conn;
	static PreparedStatement pgetcat,pprodgetBycat;
	static {
		conn=DBUtil.getMyConnection();
		try {
			pgetcat=conn.prepareStatement("select * from category");
			pprodgetBycat=conn.prepareStatement("select * from product1 where cid=?");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	@Override
	public List<Category> getAllCategory() {
		try {
			ResultSet rs=pgetcat.executeQuery();
			List<Category> clist=new ArrayList<>();
			while(rs.next()) {
				Category c=new Category(rs.getInt(1),rs.getString(2),rs.getString(3));
				clist.add(c);
			}
			return clist;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	@Override
	public List<Product> findByCategory(int cat) {
		try {
			pprodgetBycat.setInt(1, cat);
			ResultSet rs=pprodgetBycat.executeQuery();
			List<Product> plist=new ArrayList<>();
			while(rs.next()) {
				Product p=new Product(rs.getInt(1),rs.getString(2),rs.getInt(3),rs.getDouble(4),rs.getInt(5));
				plist.add(p);
			}
			return plist;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return null;
	}

}
