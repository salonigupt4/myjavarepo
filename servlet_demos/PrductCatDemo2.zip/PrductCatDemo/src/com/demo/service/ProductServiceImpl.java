package com.demo.service;

import java.util.List;

import com.demo.bean.Category;
import com.demo.bean.Product;
import com.demo.dao.ProductDao;
import com.demo.dao.ProductDaoImpl;

public class ProductServiceImpl implements ProductService{
	private ProductDao productDao;
	

	public ProductServiceImpl() {
		super();
		productDao=new ProductDaoImpl();
	}

	@Override
	public List<Category> findAllcategory() {
		return productDao.getAllCategory();
		
	}

	@Override
	public List<Product> getByCategory(int cat) {
		return productDao.findByCategory(cat);
		
	}

	@Override
	public int addproduct(Product p) {
		return productDao.insertProduct(p);
		
	}
	

}
