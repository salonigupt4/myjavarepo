package com.demo.service;

import java.util.List;

import com.demo.bean.Category;
import com.demo.bean.Product;

public interface ProductService {

	List<Category> findAllcategory();

	List<Product> getByCategory(int cat);

	int addproduct(Product p);

}
